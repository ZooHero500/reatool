# 실습 키트로 시작하기

키트에는 공식 샘플 파일 6개, 바로 실행할 수 있는 CSV 검사 스크립트, 예상 출력과 8개 언어의 설명이 들어 있습니다. 압축을 풀고 코딩 에이전트에서 notes-example 폴더를 연 다음 아래 분석 프롬프트를 복사하세요. npm install이나 Electron 실행은 필요하지 않습니다.

https://reatool.dev/ko/install/

프롬프트를 보내기 전에 코딩 에이전트에서 압축을 푼 notes-example 폴더를 여세요. 에이전트가 다른 폴더에서 작업 중이라면 샘플 폴더의 전체 경로를 알려 주세요.

```text
REA로 현재 작업 공간에 열려 있는 notes-example 폴더를 정적으로 분석해 주세요. Export notes 버튼에서 렌더러, preload 브리지, 메인 프로세스로 이어지는 흐름을 추적해 주세요. 출력 파일 경로, CSV 열 이름, 근거가 되는 파일과 줄 번호를 제시해 주세요. Electron은 실행하지 마세요. 코드에서 확인한 사실과 추정을 구분해 주세요.
```

압축을 푼 폴더에서 터미널을 열고 검사를 실행하세요:

```sh
node check.cjs
```

성공하면 마지막에 PASS: 3 CSV checks가 표시됩니다. 쉼표, 따옴표, 빈 입력, 여러 줄 제목을 검사합니다. CSV 포맷 함수만 테스트하며 앱의 내보내기 버튼을 누르지는 않습니다.

```csv
id,title
1,"Hello, ""REA"""
```

## 검사에 실패했다면

Node가 check.cjs 또는 csv.js를 찾지 못하면 키트 전체의 압축을 풀었는지, notes-example 폴더를 열었는지 확인하세요. 단언 검사에 실패하면 출력을 expected.csv와 비교하고, 코드를 수정하기 전에 새로 압축을 풀어 다시 시도하세요.

https://reatool.dev/ko/first-analysis/
