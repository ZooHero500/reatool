# 从练习包开始

练习包包含官方的六个样本文件、可直接运行的 CSV 检查脚本、预期结果和八种语言的说明。解压后，在编程助手中打开 notes-example 文件夹，再复制下方分析提示词。无需运行 npm install，也不用启动 Electron。

https://reatool.dev/zh-cn/install/

发送提示词前，先在编程助手中打开解压后的 notes-example 文件夹。如果助手正在其他目录工作，请提供样本文件夹的完整路径。

```text
使用 REA 静态分析当前工作区中的 notes-example 文件夹。沿着渲染进程、preload 桥接层和主进程追踪 Export notes 按钮的调用流程。给出输出文件路径、CSV 列名，以及支持结论的文件和行号。不要启动 Electron。明确区分代码中观察到的事实和推测。
```

在解压后的文件夹中打开终端，运行检查：

```sh
node check.cjs
```

运行成功后，最后会显示 PASS: 3 CSV checks。脚本检查逗号、引号、空数据和多行标题的处理结果，验证的是 CSV 格式化函数，不会点击应用的导出按钮。

```csv
id,title
1,"Hello, ""REA"""
```

## 检查失败怎么办

如果 Node 找不到 check.cjs 或 csv.js，请确认已完整解压练习包，并进入 notes-example 文件夹。如果断言失败，先将输出与 expected.csv 对比，再重新解压一份干净的样本重试，不要急着改代码。

https://reatool.dev/zh-cn/first-analysis/
