# Commencer avec le kit d’exercice

Le kit contient les six fichiers de l’exemple officiel, un script de vérification CSV prêt à l’emploi, le résultat attendu et des instructions en huit langues. Décompressez-le, ouvrez le dossier notes-example dans votre agent, puis copiez la consigne d’analyse ci-dessous. Il n’est pas nécessaire d’exécuter npm install ni de lancer Electron.

https://reatool.dev/fr/install/

Avant d’envoyer cette consigne, ouvrez le dossier notes-example décompressé dans votre agent. Si l’agent travaille dans un autre répertoire, donnez-lui le chemin complet du dossier.

```text
Utilise REA pour analyser statiquement le dossier notes-example ouvert dans cet espace de travail. Suis le parcours du bouton Export notes à travers le processus de rendu, le pont preload et le processus principal. Indique le chemin du fichier de sortie, les colonnes CSV, ainsi que les fichiers et lignes qui justifient ta réponse. Ne lance pas Electron. Distingue les faits observés dans le code des hypothèses.
```

Ouvrez un terminal dans le dossier décompressé et lancez la vérification :

```sh
node check.cjs
```

En cas de réussite, la dernière ligne affiche PASS: 3 CSV checks. Le script vérifie les virgules, les guillemets, une entrée vide et un titre sur plusieurs lignes. Il teste la fonction de formatage CSV ; il ne clique pas sur le bouton d’export de l’application.

```csv
id,title
1,"Hello, ""REA"""
```

## Si la vérification échoue

Si Node ne trouve pas check.cjs ou csv.js, vérifiez que vous avez décompressé tout le kit et ouvert le dossier notes-example. Si une assertion échoue, comparez la sortie avec expected.csv et réessayez avec une copie fraîchement décompressée avant de modifier le code.

https://reatool.dev/fr/first-analysis/
