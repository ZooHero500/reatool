# Start with the practice kit

The kit includes the official six-file sample, a ready-to-run CSV check, expected output and instructions in eight languages. Extract it, open the notes-example folder in your coding agent, and copy the analysis prompt below. No npm install or Electron launch is needed.

https://reatool.dev/install/

Open the extracted notes-example folder in your coding agent before sending this prompt. If the agent is working elsewhere, give it the full folder path.

```text
Use REA to statically inspect the notes-example folder open in this workspace. Trace the Export notes button through the renderer, preload bridge and main process. Show the output file path, CSV columns, and the files and lines that support your answer. Do not launch Electron. Separate observed code from assumptions.
```

Open a terminal in the extracted folder and run the check:

```sh
node check.cjs
```

A successful run ends with PASS: 3 CSV checks. It checks commas, quotation marks, empty input and a multiline title. This tests the CSV formatter; it does not click the app’s export button.

```csv
id,title
1,"Hello, ""REA"""
```

## If the check fails

If Node cannot find check.cjs or csv.js, make sure you extracted the whole kit and opened the notes-example folder. If an assertion fails, compare the output with expected.csv and start again with a fresh extraction before changing any code.

https://reatool.dev/first-analysis/
