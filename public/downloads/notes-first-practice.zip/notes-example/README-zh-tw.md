# 從練習包開始

練習包包含官方的六個範例檔案、可直接執行的 CSV 檢查程式、預期結果與八種語言的說明。解壓縮後，在程式助理中開啟 notes-example 資料夾，再複製下方分析提示詞。不必執行 npm install，也不必啟動 Electron。

https://reatool.dev/zh-tw/install/

傳送提示詞前，先在程式助理中開啟解壓縮後的 notes-example 資料夾。如果助理正在其他目錄工作，請提供範例資料夾的完整路徑。

```text
使用 REA 靜態分析目前工作區中的 notes-example 資料夾。沿著轉譯程序、preload 橋接層與主程序追蹤 Export notes 按鈕的呼叫流程。提供輸出檔案路徑、CSV 欄位名稱，以及支持結論的檔案與行號。不要啟動 Electron。明確區分從程式碼觀察到的事實與推測。
```

在解壓縮後的資料夾中開啟終端機，執行檢查：

```sh
node check.cjs
```

執行成功後，最後會顯示 PASS: 3 CSV checks。程式會檢查逗號、引號、空資料與多行標題的處理結果，驗證的是 CSV 格式化函式，不會點擊應用程式的匯出按鈕。

```csv
id,title
1,"Hello, ""REA"""
```

## 檢查失敗時怎麼辦

如果 Node 找不到 check.cjs 或 csv.js，請確認已完整解壓縮練習包，並進入 notes-example 資料夾。如果斷言失敗，先將輸出與 expected.csv 比對，再重新解壓縮一份原始範例重試，暫時不要修改程式碼。

https://reatool.dev/zh-tw/first-analysis/
