# Empieza con el kit de práctica

El kit incluye los seis archivos del ejemplo oficial, un script de comprobación de CSV listo para ejecutar, el resultado esperado e instrucciones en ocho idiomas. Descomprímelo, abre la carpeta notes-example en tu agente y copia el prompt de análisis de abajo. No necesitas ejecutar npm install ni iniciar Electron.

https://reatool.dev/es/install/

Antes de enviar este prompt, abre la carpeta notes-example descomprimida en tu agente. Si el agente está trabajando en otro directorio, indícale la ruta completa de la carpeta.

```text
Usa REA para analizar estáticamente la carpeta notes-example abierta en este espacio de trabajo. Sigue el recorrido del botón Export notes a través del renderizador, el puente preload y el proceso principal. Indica la ruta del archivo de salida, las columnas CSV y los archivos y líneas que respaldan tu respuesta. No inicies Electron. Distingue lo observado en el código de las suposiciones.
```

Abre una terminal en la carpeta descomprimida y ejecuta la comprobación:

```sh
node check.cjs
```

Si todo va bien, la última línea será PASS: 3 CSV checks. Se comprueban comas, comillas, entradas vacías y títulos de varias líneas. Esto prueba la función que genera el CSV; no pulsa el botón de exportación de la aplicación.

```csv
id,title
1,"Hello, ""REA"""
```

## Si la comprobación falla

Si Node no encuentra check.cjs o csv.js, comprueba que has descomprimido todo el kit y abierto la carpeta notes-example. Si falla una aserción, compara la salida con expected.csv y vuelve a intentarlo con una copia recién descomprimida antes de modificar el código.

https://reatool.dev/es/first-analysis/
