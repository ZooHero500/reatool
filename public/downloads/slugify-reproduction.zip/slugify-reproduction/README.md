# REA Tool — slugify reproduction

Case: https://reatool.dev/cases/slugify/
Target: slugify 1.6.6 (MIT); REA analysis performed with 6.4.0.

## Run the eight behavior checks

With Node.js 22.19+ (22.x), 24.11+ (24.x), or 26+ and npm:

```sh
npm install --ignore-scripts
node verify.mjs
```

The runner executes the original npm package, prints the assertion count and writes checks.json.
It exits with an error if a check fails. It does not start a server or upload inputs.

## Collect fresh static evidence

```sh
npm pack slugify@1.6.6
tar -xzf slugify-1.6.6.tgz
npx -y rea-agents@6.4.0 analyze-javascript-application ./package --json > analysis.json
```

REA statically inspects the extracted distribution. This step does not execute slugify.
Read package/slugify.js lines 18–61 and compare the punctuation filter to the assertion results.
Keep the partial-coverage limitations in REA's report. Eight assertions are not exhaustive Unicode testing.

## Attribution

slugify by simov and contributors, MIT license: https://github.com/simov/slugify
This kit is an independent REA Tool example, not an official REA release.
